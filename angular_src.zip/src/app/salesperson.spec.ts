import { Salesperson } from './salesperson';

describe('Salesperson', () => {
  it('should create an instance', () => {
    expect(new Salesperson()).toBeTruthy();
  });
});
