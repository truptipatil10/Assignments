import { Component, OnInit } from '@angular/core';
import { salesperson } from '../salesperson';

@Component({
  selector: 'app-sales-person-list',
  templateUrl: './sales-person-list.component.html',
  styleUrls: ['./sales-person-list.component.css']
})
export class SalesPersonListComponent implements OnInit {

  name : String = "trupti";
  s1: salesperson = new salesperson("Trupti","patil","trupti@gmail.com",34000,"200");

salesList :salesperson[] = [
                              this.s1,
                              new salesperson("Trupti","patil","trupti@gmail.com",34000,"200"),
                              new salesperson("Teena","pawar","teena@gmail.com",1000,"200"),
                              new salesperson("shital","jitakar","shital@gmail.com",32000,"200"),
                              new salesperson("appasara","Ganesh","appassara@gmail.com",1000,"200"),
                              new salesperson("saloni","mathur","saloni@gmail.com",34000,"200")
                          ]
formModel : salesperson=new salesperson("","","",0,"");


  constructor() { }

  ngOnInit(): void {

    // console.log(this.formModel)
    // this.salesList.push(this.formModel);
  }
  onSubmit()
  {
    this.salesList.push(this.formModel);
  }

}